#!/usr/bin/env bash
# Mostra e controla os modelos do llama-server (modo roteador).
#
# Uso:
#   scripts/modelos.sh                 lista os modelos e qual está carregado
#   scripts/modelos.sh carregar <nome> carrega um modelo (descarrega o atual)
#   scripts/modelos.sh descarregar     libera a VRAM (descarrega o modelo atual)
#
# Normalmente nada disso é necessário: pedir um modelo na API ou no Open WebUI já faz
# a troca sozinho (leva de alguns segundos a ~1 min, conforme o tamanho).
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/_env.sh; carregar_env

api() { docker exec llamacpp curl -fsS -H "Authorization: Bearer $MOTOR_API_KEY" \
          -H "Content-Type: application/json" "$@"; }

listar() {
  api http://localhost:8080/models > /tmp/modelos-status.json
  python3 - /tmp/modelos-status.json << 'PY'
import json, sys
for m in json.load(open(sys.argv[1]))["data"]:
    st = m.get("status", {})
    falhou = "  (FALHOU ao carregar: veja docker logs llamacpp)" if st.get("failed") else ""
    print("  %-24s %s%s" % (m["id"], st.get("value", "?"), falhou))
PY
}

case "${1:-listar}" in
  listar) listar ;;
  carregar)
    N=${2:?informe o nome}
    api -X POST http://localhost:8080/models/load -d "{\"model\":\"$N\"}" >/dev/null
    printf "carregando %s" "$N"
    for i in $(seq 1 60); do
      if listar | grep -qE "^  $N +loaded"; then echo; listar; exit 0; fi
      printf "."; sleep 3
    done
    echo; listar ;;
  descarregar)
    for N in $(listar | awk '$2=="loaded"{print $1}'); do
      api -X POST http://localhost:8080/models/unload -d "{\"model\":\"$N\"}" >/dev/null
      echo "descarregado: $N"
    done ;;
  *) echo "uso: scripts/modelos.sh [listar | carregar <nome> | descarregar]"; exit 1 ;;
esac
