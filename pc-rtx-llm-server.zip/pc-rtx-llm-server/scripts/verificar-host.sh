#!/usr/bin/env bash
# Verificações antes de subir o serviço. Não precisa de sudo.
ok()   { printf "  \e[32m[ok]\e[0m %s\n" "$*"; }
warn() { printf "  \e[33m[!!]\e[0m %s\n" "$*"; }
fail() { printf "  \e[31m[xx]\e[0m %s\n" "$*"; FAILED=1; }
FAILED=0
cd "$(dirname "$0")/.."
source scripts/_env.sh

echo "== Usuário e Docker"
id -nG | grep -qw docker && ok "usuário no grupo docker" || fail "usuário fora do grupo docker (sudo usermod -aG docker $USER e entre de novo)"
docker info >/dev/null 2>&1 && ok "daemon Docker acessível" || fail "não consegui falar com o Docker"
docker compose version >/dev/null 2>&1 && ok "docker compose disponível" || fail "falta o docker-compose-plugin"
docker info 2>/dev/null | grep -qi "nvidia" && ok "runtime NVIDIA registrado no Docker" || fail "runtime NVIDIA ausente (NVIDIA Container Toolkit, INSTALL.md passo 3)"

echo "== GPU e driver"
if command -v nvidia-smi >/dev/null && nvidia-smi >/dev/null 2>&1; then
  IFS=, read -r NOME DRV TOT USADO < <(nvidia-smi --query-gpu=name,driver_version,memory.total,memory.used --format=csv,noheader,nounits | head -1)
  ok "GPU:$NOME | driver $DRV | VRAM ${TOT// /} MiB, ${USADO// /} MiB em uso"
  MAJ=${DRV%%.*}; MAJ=${MAJ// /}
  [ "${MAJ:-0}" -ge 575 ] && ok "driver $MAJ (RTX 50xx precisa de 575 ou mais novo)" || fail "driver $MAJ antigo para RTX 50xx (instale 575+ open)"
  [ "${USADO// /}" -lt 1500 ] && ok "pouca VRAM ocupada por outros programas" || warn "${USADO// /} MiB já em uso (navegador/jogos/outros modelos); feche o que puder"
  CUDA_DRV=$(nvidia-smi | grep -oE "CUDA Version: [0-9.]+" | awk '{print $3}')
else
  fail "nvidia-smi não funciona: driver NVIDIA não instalado ou não carregado (INSTALL.md passo 1)"
fi

echo "== Memória e disco"
DISP=$(free -g | awk '/^Mem:/ {print $7}')
[ "${DISP:-0}" -ge 8 ] && ok "${DISP} GB de RAM disponíveis" || warn "só ${DISP} GB de RAM disponíveis"
LIVRE=$(df -BG --output=avail "$HOME" | tail -1 | tr -dc 0-9)
[ "${LIVRE:-0}" -ge 40 ] && ok "${LIVRE} GB livres em disco" || warn "só ${LIVRE} GB livres em disco"

echo "== Portas"
for p in 80 443 4000 8443; do
  ss -ltn "( sport = :$p )" | grep -q LISTEN && fail "porta $p já em uso" || ok "porta $p livre"
done

echo "== Configuração"
if [ -f .env ]; then
  ok ".env existe"
  carregar_env
  for V in MOTOR_API_KEY LITELLM_MASTER_KEY LITELLM_SALT_KEY POSTGRES_PASSWORD WEBUI_SECRET_KEY; do
    VAL=${!V:-}; [ ${#VAL} -ge 20 ] || fail "segredo $V vazio (rode scripts/gerar-segredos.sh)"
  done
  [ -d "${MODELS_DIR:-/x}" ] && ok "MODELS_DIR existe ($MODELS_DIR)" || fail "MODELS_DIR não existe: ${MODELS_DIR:-não definido}"
  [[ "${SERVER_NAME:-}" == IP_OU_NOME* || -z "${SERVER_NAME:-}" ]] && fail "defina SERVER_NAME no .env" || ok "SERVER_NAME=$SERVER_NAME"
  if [ -n "${CUDA_DRV:-}" ]; then
    python3 -c "import sys; a=[int(x) for x in '${CUDA_VERSION}'.split('.')[:2]]; b=[int(x) for x in '$CUDA_DRV'.split('.')[:2]]; sys.exit(0 if a<=b else 1)" \
      && ok "CUDA_VERSION=$CUDA_VERSION compatível com o driver (até CUDA $CUDA_DRV)" \
      || fail "CUDA_VERSION=$CUDA_VERSION maior que a suportada pelo driver (CUDA $CUDA_DRV); ajuste no .env"
  fi
  for SN in "$DOCKER_SUBNET_BACKEND" "$DOCKER_SUBNET_FRONTEND"; do
    PFX=$(echo "$SN" | cut -d. -f1-2)
    ip -4 route | grep -q "^$PFX\." && warn "sub-rede $SN coincide com uma rota do host; escolha outra" || ok "sub-rede $SN sem conflito"
  done
else
  fail "falta .env (cp .env.example .env)"
fi
[ -f nginx/certs/fullchain.pem ] && [ -f nginx/certs/privkey.pem ] && ok "certificados presentes" || warn "sem certificados (scripts/gerar-certificado.sh)"
NMOD=$(grep -cE '^\[[^*]' llamacpp/modelos.ini || true)
[ "${NMOD:-0}" -ge 1 ] && ok "$NMOD modelo(s) em llamacpp/modelos.ini" || warn "nenhum modelo registrado ainda (scripts/adicionar-modelo.sh)"

echo
[ $FAILED -eq 0 ] && echo "Pronto para seguir." || echo "Resolva os itens [xx] antes de continuar."
exit $FAILED
