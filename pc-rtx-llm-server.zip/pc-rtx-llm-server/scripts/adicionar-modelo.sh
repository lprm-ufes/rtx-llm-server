#!/usr/bin/env bash
# Baixa um modelo GGUF e o registra no llama.cpp e no LiteLLM.
#
# Uso:
#   scripts/adicionar-modelo.sh --listar <repo-hf>
#   scripts/adicionar-modelo.sh <nome> <repo-hf> <quantização> [opções]
#
# Opções:
#   --ctx N            contexto total desse modelo (padrão: o de [*] em modelos.ini)
#   --sem-raciocinio   raciocínio desligado por padrão (Qwen3 e similares)
#   --padrao           carrega este modelo ao ligar o serviço
#
# Exemplo:
#   scripts/adicionar-modelo.sh qwen3-8b Qwen/Qwen3-8B-GGUF Q4_K_M --sem-raciocinio --padrao
set -euo pipefail
cd "$(dirname "$0")/.."
source scripts/_env.sh; carregar_env

TOKEN=${HF_TOKEN:-}
AUTH=(); [ -n "$TOKEN" ] && AUTH=(-H "Authorization: Bearer $TOKEN")

if [ "${1:-}" = "--listar" ]; then
  REPO=${2:?informe o repositório}
  curl -fsS "${AUTH[@]}" "https://huggingface.co/api/models/$REPO?blobs=true" > /tmp/gguf-lista.json
  python3 - /tmp/gguf-lista.json << 'PY'
import json, sys
fs = [s for s in json.load(open(sys.argv[1]))["siblings"] if s["rfilename"].endswith(".gguf")]
for s in sorted(fs, key=lambda s: s.get("size") or 0):
    tag = "  (visão, não precisa)" if "mmproj" in s["rfilename"].lower() else ""
    print("%7.1f GB  %s%s" % ((s.get("size") or 0) / 1e9, s["rfilename"], tag))
PY
  echo
  echo "Com 8 GB de VRAM: arquivos de até ~6 GB, para sobrar espaço para o contexto."
  exit 0
fi

NOME=${1:?uso: scripts/adicionar-modelo.sh <nome> <repo-hf> <quantização> [opções]}
REPO=${2:?informe o repositório do Hugging Face}
QUANT=${3:?informe a quantização (veja --listar)}
shift 3
CTX=""; SEM_RAC=0; PADRAO=0
while [ $# -gt 0 ]; do
  case "$1" in
    --ctx) CTX=${2:?}; shift 2 ;;
    --sem-raciocinio) SEM_RAC=1; shift ;;
    --padrao) PADRAO=1; shift ;;
    *) echo "opção desconhecida: $1"; exit 1 ;;
  esac
done
[[ "$NOME" =~ ^[a-z0-9][a-z0-9._-]*$ ]] || { echo "nome inválido (use minúsculas, números, . _ -)"; exit 1; }

DEST="$MODELS_DIR/$NOME"
mkdir -p "$DEST"
echo "== Baixando *$QUANT*.gguf de $REPO para $DEST"
docker run --rm -e HF_TOKEN="$TOKEN" -e HOME=/tmp \
  -v "$DEST:/out" python:3.12-slim bash -c '
    pip install -q --root-user-action=ignore -U huggingface_hub >/dev/null
    hf download "$1" --include "*$2*.gguf" --exclude "*mmproj*" --local-dir /out
    rm -rf /out/.cache
    chown -R "$3" /out' _ "$REPO" "$QUANT" "$(id -u):$(id -g)"

LISTA=$(cd "$DEST" && ls -1 | grep -i -- "$QUANT" | grep -iv mmproj | grep -E '\.gguf$' || true)
ARQ=$(echo "$LISTA" | grep -E -- '-0*1-of-' | head -1 || true)
[ -n "$ARQ" ] || ARQ=$(echo "$LISTA" | head -1)
[ -n "$ARQ" ] || { echo "Nenhum .gguf com '$QUANT' encontrado. Veja as opções com --listar."; exit 1; }
echo "== Arquivo: $ARQ ($(du -sh "$DEST" | cut -f1))"

# --- llamacpp/modelos.ini: (re)escreve a seção [NOME]
python3 - llamacpp/modelos.ini "$NOME" "/models/$NOME/$ARQ" "$CTX" "$SEM_RAC" "$PADRAO" << 'PY'
import re, sys
arq, nome, caminho, ctx, sem_rac, padrao = sys.argv[1:]
linhas = open(arq).read().splitlines()
saida, pular = [], False
for l in linhas:
    m = re.match(r"\s*\[(.+)\]\s*$", l)
    if m:
        pular = (m.group(1) == nome)
    if pular:
        continue
    if padrao == "1" and re.match(r"\s*load-on-startup\s*=", l):
        continue
    saida.append(l)
while saida and not saida[-1].strip():
    saida.pop()
saida += ["", f"[{nome}]", f"model = {caminho}"]
if ctx:          saida.append(f"c = {ctx}")
if sem_rac == "1": saida.append("reasoning = off")
if padrao == "1":  saida.append("load-on-startup = true")
open(arq, "w").write("\n".join(saida) + "\n")
PY

# --- litellm/config.yaml: acrescenta o modelo se ainda não existir
if ! grep -qE "^  - model_name: $NOME\$" litellm/config.yaml; then
  python3 - litellm/config.yaml "$NOME" << 'PY'
import sys
arq, nome = sys.argv[1:]
s = open(arq).read()
bloco = (f"  - model_name: {nome}\n"
         f"    litellm_params:\n"
         f"      model: openai/{nome}\n"
         f"      api_base: http://llamacpp:8080/v1\n"
         f"      api_key: os.environ/MOTOR_API_KEY\n"
         f"      timeout: 600\n")
s = s.replace("model_list:\n", "model_list:\n" + bloco, 1)
open(arq, "w").write(s)
PY
fi
echo "== Registrado como '$NOME' em llamacpp/modelos.ini e litellm/config.yaml"

for c in llamacpp litellm; do
  if [ "$(docker inspect -f '{{.State.Running}}' "$c" 2>/dev/null)" = true ]; then
    echo "== Reiniciando $c"; docker compose restart "$c" >/dev/null
  fi
done
echo "Pronto. Use \"model\": \"$NOME\" na API ou escolha '$NOME' no Open WebUI."
